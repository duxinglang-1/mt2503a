/* Copyright Statement:
 *
 * (C) 2005-2016  MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. ("MediaTek") and/or its licensors.
 * Without the prior written permission of MediaTek and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 * You may only use, reproduce, modify, or distribute (as applicable) MediaTek Software
 * if you have agreed to and been bound by the applicable license agreement with
 * MediaTek ("License Agreement") and been granted explicit permission to do so within
 * the License Agreement ("Permitted User").  If you are not a Permitted User,
 * please cease any access or use of MediaTek Software immediately.
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT MEDIATEK SOFTWARE RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES
 * ARE PROVIDED TO RECEIVER ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 */

#if 1//def __ST_LSM6DS3__
#include "lsm6ds3.h"
#include "lsm6ds3_app.h"
#include "lsm6ds3_i2c_operation.h"
#include "kal_public_api.h"
#include "dcl.h"
#include "kal_trace.h"
#include "kal_release.h"
#include "drv_comm.h"

lsm6ds3tr_c_ctx_t lsm6ds3;
uint16_t pattern_len;
static axis3bit16_t data_raw_acceleration;
static axis3bit16_t data_raw_angular_rate;
static float acceleration_mg[3];
static float angular_rate_mdps[3]; 
extern  int32_t lsm6ds3tr_c_write_reg(lsm6ds3tr_c_ctx_t* ctx, uint8_t reg, uint8_t* data,uint16_t len);

S32 LSM6DS3_bus_write(uint8_t wire_type, uint8_t reg_addr, uint8_t* reg_data, uint16_t data_len)
{
	S32 iError = 0;
	
	iError = lsm6ds3_i2c_send(LSM6DS3TR_C_I2C_ADD_L, reg_addr, reg_data, data_len);
	return iError;
}

S32 LSM6DS3_bus_read(uint8_t wire_type, uint8_t reg_addr, uint8_t* reg_data, uint16_t data_len)
{
	S32 iError = 0;
	
	iError = lsm6ds3_i2c_receive(LSM6DS3TR_C_I2C_ADD_L, reg_addr, reg_data, data_len);
	return iError;
}

void LSM6DS3_delay_msek(U32 msek)
{
    /*Here you can write your own delay routine*/
    kal_sleep_task(msek/KAL_MILLISECS_PER_TICK+1);
}

/*--------------------------------------------------------------------------*
 *  By using lsm6ds3 the following structure parameter can be accessed
 *  Bus write function pointer: platform_write
 *  Bus read function pointer: platform_read
 *  Delay function pointer: delay_msec
 *  I2C address: dev_addr
 *--------------------------------------------------------------------------*/
S32 lsm6ds3_wire_connection_routine(uint8_t wire_type)
{
    S32 iError = STATUS_OK; 

		
    if(wire_type >= LSM6DS3_WIRE_TYPE_MAX) return STATUS_INVALID_CTRL_DATA;
    switch(wire_type)
    {
    	case LSM6DS3_WIRE_TYPE_I2C:
	{
    		iError = lsm6ds3_i2c_configure(LSM6DS3TR_C_I2C_ADD_L, 400); 
	
			lsm6ds3.write_reg = LSM6DS3_bus_write;
			lsm6ds3.read_reg = LSM6DS3_bus_read;
    		break;
    	}
    	case LSM6DS3_WIRE_TYPE_SPI:
    		//reserved for SPI wire connection way
    		break;
    		
    	default:
    		break;
    }
    return iError;
}

S32 init_lsm6ds3(void)
{
	S32 error = STATUS_OK;
	U8 device_id, rst;
	//init I2C
	error = (lsm6ds3_wire_connection_routine(LSM6DS3_WIRE_TYPE_I2C));
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of init_I2C is:""%d", error);
	if(error!= STATUS_OK) return error;
	
	//read device id
	error = lsm6ds3tr_c_device_id_get(&lsm6ds3, &device_id); 
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of get_device_id and device id  are:""%d,%x", error,device_id);
	if (device_id != LSM6DS3TR_C_ID) return STATUS_DEVICE_NOT_EXIST;

	//software reset,gyr and acc in power down mode
	error = lsm6ds3tr_c_reset_set(&lsm6ds3, PROPERTY_ENABLE);  
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of software_reset  is:""%d", error);
	if(error!= STATUS_OK) return error;
	do {	  lsm6ds3tr_c_reset_get(&lsm6ds3, &rst);  } while (rst);

	return STATUS_OK;
	
}

 S32 config_lsm6ds3(void)
{
	S32 error = STATUS_OK;
	U8 device_id, rst,temp_val;
	uint8_t temp[2];

	lsm6ds3tr_c_int1_route_t int_1_reg;
	
	//read device id
	
	error = lsm6ds3tr_c_device_id_get(&lsm6ds3, &device_id); 
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of get_device_id and device id  are:""%d,%x", error,device_id);
	if (device_id != LSM6DS3TR_C_ID) return STATUS_DEVICE_NOT_EXIST;

	//enable block data update
	error = lsm6ds3tr_c_block_data_update_set(&lsm6ds3, PROPERTY_ENABLE);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of block_data_update  is:""%d", error);
	if(error!= STATUS_OK) return error;
	
	//set acc and gry full-scale 
	error = lsm6ds3tr_c_xl_full_scale_set(&lsm6ds3, LSM6DS3TR_C_2g); 
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_acc_full_scale is:""%d", error);
	if(error!= STATUS_OK) return error;
	error = lsm6ds3tr_c_gy_full_scale_set(&lsm6ds3, LSM6DS3TR_C_250dps);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_gry_full_scale is:""%d", error);
	if(error!= STATUS_OK) return error;
	
	//set acc and gry data rate
	error = lsm6ds3tr_c_xl_data_rate_set(&lsm6ds3, LSM6DS3TR_C_XL_ODR_208Hz);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_acc_data_rate  is:""%d", error);
	if(error!= STATUS_OK) return error;
	error = lsm6ds3tr_c_gy_data_rate_set(&lsm6ds3, LSM6DS3TR_C_GY_ODR_208Hz);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_gry_data_rate  is:""%d", error);
	if(error!= STATUS_OK) return error;

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_CTRL1_XL, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_CTRL1_XL  are:""%d,%x", error,temp_val);
	
/*	
	//set int2 for acc and gry data ready
	error = lsm6ds3_pin_int2_route_get(&lsm6ds3, &int_2_reg); 
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of get_int2_route  is:""%d", error);
	if(error!= STATUS_OK) return error;
	int_2_reg.int2_drdy_g = PROPERTY_ENABLE;  
	int_2_reg.int2_drdy_xl = PROPERTY_ENABLE;  
	error = lsm6ds3_pin_int2_route_set(&lsm6ds3, &int_2_reg);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_int2_route  is:""%d", error);
	if(error!= STATUS_OK) return error;
*/
	//set int1 for acc and gry data ready
	error = lsm6ds3tr_c_pin_int1_route_get(&lsm6ds3, &int_1_reg); 
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of get_int1_route  is:""%d", error);
	if(error!= STATUS_OK) return error;
	int_1_reg.int1_drdy_g = PROPERTY_ENABLE;  
	int_1_reg.int1_drdy_xl = PROPERTY_ENABLE;  
	error = lsm6ds3tr_c_pin_int1_route_set(&lsm6ds3, int_1_reg);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_int1_route  is:""%d", error);
	if(error!= STATUS_OK) return error;
#if 0
	temp[0]=0x80;
	error = lsm6ds3_write_reg(&lsm6ds3, LSM6DS3_INT1_CTRL, temp, 1);
	kal_prompt_trace(MOD_ABM, " TEST:DBG error and LSM6DS3_INT1_CTRL  are:""%d,%x", error,temp_val);
	temp[0]=0x40;
	error = lsm6ds3_write_reg(&lsm6ds3, LSM6DS3_TAP_CFG, temp, 1);
	kal_prompt_trace(MOD_ABM, " TEST:DBG error and LSM6DS3_TAP_CFG  are:""%d,%x", error,temp_val);
	temp[0]=0x3c;
	error = lsm6ds3_write_reg(&lsm6ds3, LSM6DS3_CTRL10_C, temp, 1);
	kal_prompt_trace(MOD_ABM, " TEST:DBG error and LSM6DS3_CTRL10_C  are:""%d,%x", error,temp_val);
#endif


//read registers
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_CTRL3_C, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_CTRL3_C  are:""%d,%x", error,temp_val);

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_CTRL1_XL, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_CTRL1_XL  are:""%d,%x", error,temp_val);

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_CTRL2_G, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_CTRL2_G  are:""%d,%x", error,temp_val);

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_INT1_CTRL, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_INT1_CTRL  are:""%d,%x", error,temp_val);

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_WHO_AM_I, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_WHO_AM_I  are:""%d,%x", error,temp_val); 	

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_CTRL10_C, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_CTRL10_C  are:""%d,%x", error,temp_val); 	

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_TAP_CFG, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_TAP_CFG  are:""%d,%x", error,temp_val); 	

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_STEP_COUNTER_L, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_STEP_COUNTER_L  are:""%d,%x", error,temp_val); 	
	
	return STATUS_OK;
	
} 
 //LSM6DS3_INT1_CTRL 80
//LSM6DS3_TAP_CFG 40
// LSM6DS3_CTRL10_C 3c

void fdfsdfdsfsdfd()
{
	 S32 error = STATUS_OK;
	 U8 device_id, rst,temp_val;

	 temp_val = 0;
	 error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_STEP_COUNTER_L, &temp_val, 1);
	 kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_STEP_COUNTER_L  are:""%d,%x", error,temp_val);  

}
 
 S32 config_lsm6ds3_stop(void)
{
	S32 error = STATUS_OK;
	U8 device_id, rst,temp_val;

	lsm6ds3tr_c_int1_route_t int_1_reg;
	
	//read device id
	error = lsm6ds3tr_c_device_id_get(&lsm6ds3, &device_id); 
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of get_device_id and device id  are:""%d,%x", error,device_id);
	if (device_id != LSM6DS3TR_C_ID) return STATUS_DEVICE_NOT_EXIST;

	//enable block data update
	error = lsm6ds3tr_c_block_data_update_set(&lsm6ds3, PROPERTY_ENABLE);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of block_data_update  is:""%d", error);
	if(error!= STATUS_OK) return error;
	
	//set acc and gry full-scale 
	error = lsm6ds3tr_c_xl_full_scale_set(&lsm6ds3, LSM6DS3TR_C_2g); 
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_acc_full_scale is:""%d", error);
	if(error!= STATUS_OK) return error;
	error = lsm6ds3tr_c_gy_full_scale_set(&lsm6ds3, LSM6DS3TR_C_2000dps);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_gry_full_scale is:""%d", error);
	if(error!= STATUS_OK) return error;
	
	//set acc and gry data rate
	error = lsm6ds3tr_c_xl_data_rate_set(&lsm6ds3, LSM6DS3TR_C_XL_ODR_OFF);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_acc_data_rate  is:""%d", error);
	if(error!= STATUS_OK) return error;
	error = lsm6ds3tr_c_gy_data_rate_set(&lsm6ds3, LSM6DS3TR_C_GY_ODR_OFF);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_gry_data_rate  is:""%d", error);
	if(error!= STATUS_OK) return error;
	
	//set int1 for acc and gry data ready
	error = lsm6ds3tr_c_pin_int1_route_get(&lsm6ds3, &int_1_reg); 
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of get_int1_route  is:""%d", error);
	if(error!= STATUS_OK) return error;
	int_1_reg.int1_drdy_g = PROPERTY_ENABLE;  
	int_1_reg.int1_drdy_xl = PROPERTY_ENABLE;  
	error = lsm6ds3tr_c_pin_int1_route_set(&lsm6ds3, int_1_reg);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of set_int1_route  is:""%d", error);
	if(error!= STATUS_OK) return error;

	//fifo part
	pattern_len = 12;
	error = lsm6ds3tr_c_fifo_watermark_set(&lsm6ds3, 10 * pattern_len);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of fifo watermark is:""%d", error);

	error = lsm6ds3tr_c_fifo_mode_set(&lsm6ds3, LSM6DS3TR_C_STREAM_MODE);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of fifo mode set is:""%d", error);

	error = lsm6ds3tr_c_fifo_xl_batch_set(&lsm6ds3, LSM6DS3TR_C_FIFO_XL_NO_DEC);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of accel batch set is:""%d", error);
	
	error= lsm6ds3tr_c_fifo_gy_batch_set(&lsm6ds3, LSM6DS3TR_C_FIFO_GY_NO_DEC);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of gyro batch set is:""%d", error);

	error = lsm6ds3tr_c_fifo_data_rate_set(&lsm6ds3, LSM6DS3TR_C_FIFO_208Hz);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error of fifo data rate set is:""%d", error);

	//read registers
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_CTRL3_C, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_CTRL3_C  are:""%d,%x", error,temp_val);

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_CTRL1_XL, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_CTRL1_XL  are:""%d,%x", error,temp_val);

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_CTRL2_G, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_CTRL2_G  are:""%d,%x", error,temp_val);

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_INT1_CTRL, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_INT1_CTRL  are:""%d,%x", error,temp_val);

	temp_val = 0;
	error = lsm6ds3tr_c_read_reg(&lsm6ds3, LSM6DS3TR_C_WHO_AM_I, &temp_val, 1);
	kal_prompt_trace(MOD_ABM, "YOUNG TEST:DBG error and LSM6DS3_WHO_AM_I  are:""%d,%x", error,temp_val); 	
	
	return STATUS_OK;
	
} 

S32 get_lsm6ds3_device_id(U8 *buff)
{
	S32 error;	
	error = lsm6ds3tr_c_device_id_get(&lsm6ds3, buff);
	return error;
}
 

S32 get_lsm6ds3_acceleration_raw_data(U8 *acc_data)
{
	S32 error = STATUS_OK;
	error = lsm6ds3tr_c_acceleration_raw_get(&lsm6ds3,acc_data);
	return error;
}

S32 get_lsm6ds3_angular_rate_raw_data(U8 *gyro_data)
{
	S32 error = STATUS_OK;
	error = lsm6ds3tr_c_angular_rate_raw_get(&lsm6ds3,gyro_data);
	return error;
} 

S32 get_lsm6ds3_fifo_acceleration_angular_rate_data_s16(S16 *acceleration_mg, S16 *angular_rate_mdps){
	uint16_t num = 0;
	uint16_t num_pattern = 0;
	uint8_t waterm = 0;
	S32 error = STATUS_OK;

	error = lsm6ds3tr_c_fifo_wtm_flag_get(&lsm6ds3, &waterm);
	if(error!=STATUS_OK) return error;
	if (waterm){
		error = lsm6ds3tr_c_fifo_data_level_get(&lsm6ds3, &num);
		if(error!=STATUS_OK) return error;
		num_pattern = num/pattern_len;

		while (num_pattern-- > 0){
			lsm6ds3tr_c_fifo_raw_data_get(&lsm6ds3, data_raw_angular_rate.u8bit, 3*sizeof(int16_t));
			*angular_rate_mdps = lsm6ds3tr_c_from_fs250dps_to_mdps(data_raw_angular_rate.i16bit[0]);
			*(angular_rate_mdps+1) = lsm6ds3tr_c_from_fs250dps_to_mdps(data_raw_angular_rate.i16bit[1]);
			*(angular_rate_mdps+2) = lsm6ds3tr_c_from_fs250dps_to_mdps(data_raw_angular_rate.i16bit[2]);

			lsm6ds3tr_c_fifo_raw_data_get(&lsm6ds3, data_raw_acceleration.u8bit, 3*sizeof(int16_t));
			*acceleration_mg = lsm6ds3tr_c_from_fs2g_to_mg(data_raw_acceleration.i16bit[0]);
			*(acceleration_mg+1) = lsm6ds3tr_c_from_fs2g_to_mg(data_raw_acceleration.i16bit[1]);
			*(acceleration_mg+2) = lsm6ds3tr_c_from_fs2g_to_mg(data_raw_acceleration.i16bit[2]);
		}
	}
	return error;
}

S32 get_lsm6ds3_acceleration_angular_rate_data_s16(S16 *acc_data, S16 *gyro_data)
{
	S32 error = STATUS_OK;
	U8 acc_data_u8[6] = {0},gyro_data_u8[6] = {0};

	error = lsm6ds3tr_c_acceleration_raw_get(&lsm6ds3,acc_data_u8);
	if(error!=STATUS_OK) return error;

	error = lsm6ds3tr_c_angular_rate_raw_get(&lsm6ds3,gyro_data_u8);
	if(error!=STATUS_OK) return error;

	*acc_data= 		  (S16)((acc_data_u8[1]<<8) +  acc_data_u8[0]);
	*(acc_data + 1) =    (S16)((acc_data_u8[3]<<8) +  acc_data_u8[2]);
	*(acc_data + 2) =    (S16)((acc_data_u8[5]<<8) +  acc_data_u8[4]);
	*gyro_data=  	  (S16)((gyro_data_u8[1]<<8) +  gyro_data_u8[0]);
	*(gyro_data + 1) =  (S16)((gyro_data_u8[3]<<8) +  gyro_data_u8[2]);
	*(gyro_data + 2) =  (S16)((gyro_data_u8[5]<<8) +  gyro_data_u8[4]);

	//apps_trace( "Acc [[%d][%d][%d][%d] \r\n",acc_data_u8[0], acc_data_u8[1], acc_data_u8[2],acc_data_u8[3]);

	return error;
}	

#endif
