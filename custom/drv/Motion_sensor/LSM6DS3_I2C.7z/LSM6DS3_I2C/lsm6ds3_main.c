 
#ifndef WIN32 
#include "kal_general_types.h" 
#include "kal_public_defs.h" 
#include "sw_types.h" 
#include "algorithm.h" 
#include "intrCtrl.h" 
#include "QueueGprot_Int.h" 
 
#include "stack_config.h" 
#include "stack_ltlcom.h" 
#include "stack_common.h" 
#include "stack_msgs.h" 
#include "app_ltlcom.h"         /* Task message communiction */ 
#include "task_config.h"        /* Task creation */ 
 
 
kal_bool lsm6ds3_int_gen = KAL_TRUE; 
extern void battery_low_screen_ext(); 
int dfsdfdsf = 0; 
extern const unsigned char LSM6DS3_EINT_NO; 
 
 
algo_result_ret_value lsm6ds3_data; 
algo_result_ret_value lsm6ds3_data_temp; 
 
 
extern void pedometer_draw_main_screen(); 
volatile int fall_index = 0; 
#define get_acc_magn(x)             (x*4.0f/32768.0f)       //-+4g 
#define get_gyro_magn(x)            (x*500.0f/28571.43f)    //-+500dps 
 
int stop_lsm6ds3 = 0; 
kal_bool lsm6ds3_int_stop = KAL_FALSE; 
 
extern void ls6d_fall_detect_mmi_req(void); 
extern void ls6d_fall_detect_upl_data_req(void); 
 
void ls6d_screen_display(void) 
{} 
extern S32 init_lsm6ds3(void); 
 
 
void LSM6DS3_DATA_READY_HISR(void) 
{    
 
    volatile int16_t acc_data_s16[3] = {0}, gyro_data_s16[3] = {0}; 
    volatile int result = 0; 
     
    EINT_Mask(LSM6DS3_EINT_NO);      
    get_lsm6ds3_acceleration_angular_rate_data_s16(acc_data_s16, gyro_data_s16); 
    //get_lsm6ds3_fifo_acceleration_angular_rate_data_s16(acc_data_s16, gyro_data_s16);
    #if 1//// 
    //result = algo_analyse(acc_data_s16, gyro_data_s16);
    result = algorithm_analyse(acc_data_s16, gyro_data_s16);
    if(result) 
    { 
        //ls6d_fall_detect_mmi_req(); 
        ls6d_fall_detect_upl_data_req(); 
    } 
    #else //  fall detect delay 30s  
    if(lsm6ds3_int_stop == KAL_TRUE) 
    { 
     stop_lsm6ds3++; 
    } 
 
    if(stop_lsm6ds3 >416*30) 
    { 
        stop_lsm6ds3 =0; 
        lsm6ds3_int_stop = KAL_FALSE; 
    } 
     
    dfsdfdsf = dfsdfdsf%5000; 
    dfsdfdsf++; 
 
    if(lsm6ds3_int_gen)  
    { 
        //kal_prompt_trace(MOD_ABM,"Angular rate: [%d][%d][%d] \r\n",(int16_t)(gyro_data_s16[0]*500/28571.43f),(int16_t)(gyro_data_s16[1]*500/28571.43f),(int16_t)(gyro_data_s16[2]*500/28571.43f)); 
        //lsm6ds3_data = algorithm_analyse(acc_data_s16, gyro_data_s16); 
        if(lsm6ds3_int_stop == KAL_FALSE) 
        { 
            result = algorithm_analyse(acc_data_s16, gyro_data_s16); 
		//result = algo_analyse(acc_data_s16, gyro_data_s16);
			//kal_prompt_trace(MOD_UEM,"fall_result:%d\r\n",result); 
            if(result)//(lsm6ds3_data.result) 
            { 
                fall_index++; 
                lsm6ds3_int_stop = KAL_TRUE; 
                dbg_print("fall_index %d %d %d\r\n",fall_index,result,lsm6ds3_int_stop); 
                //memset(&lsm6ds3_data_temp,0x0,sizeof(algo_result_ret_value)); 
                //memcpy(&lsm6ds3_data_temp,&lsm6ds3_data,sizeof(algo_result_ret_value)); 
                //kal_prompt_trace( MOD_ABM,"lsm6ds3_data_temp_result %d\r\n",lsm6ds3_data_temp.result); 
                //ls6d_screen_display(); 
                ls6d_fall_detect_mmi_req(); 
            } 
        } 
 
    } 
    #endif 
 
     
        EINT_UnMask(LSM6DS3_EINT_NO); 
} 
 
void lsm6ds3_main_init(void) 
{ 
 
    dbg_print("lsm6ds3_main_init\r\n"); 
    init_lsm6ds3(); 
 
    EINT_Set_HW_Debounce(LSM6DS3_EINT_NO, 0);    
    EINT_Registration(LSM6DS3_EINT_NO,KAL_TRUE,KAL_TRUE,LSM6DS3_DATA_READY_HISR, KAL_FALSE); 
    EINT_Mask(LSM6DS3_EINT_NO); 
 
     
    //algorithm_init(1, 3, 45,0.9f); 
    algorithm_init(0.05f); 
     
    config_lsm6ds3(); 
     
    EINT_UnMask(LSM6DS3_EINT_NO); 
} 
 
 
#endif 
 
 
 
 