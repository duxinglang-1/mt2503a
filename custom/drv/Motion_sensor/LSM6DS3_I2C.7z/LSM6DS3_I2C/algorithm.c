/*****************************************************************************
* File Name          : algorithm.c
* Author             : Young
* Version            : v1.0
* Date               : 15/02/2019
* Description        : algorithm for fall detection
*
* HISTORY:
* Date               |	Modification                    |	Author
* 15/02/2019         |	Initial Revision                |	Young

********************************************************************************/

#include "algorithm.h"
#include <string.h>
#include <math.h>
#include "kal_trace.h"
#include "kal_release.h"

#define FALL_DETECT_TEST_MODE     // frank_shao add for test mode
#define PRINT_RAW_DATA_TEST_MODE 


//Define low, medium, high memership
#define LOW_MS       1
#define MEDIUM_MS    2
#define HIGH_MS      3

//define the memberships of Angle input
#define LOW_ANGLE		 	20
#define MEDIUM_ANGLE 		45
#define HIGH_ANGLE 			90

//define the memberships of Gyroscope's Magnitude input
#define LOW_GYRO_MAGNITUDE 	 150 //100
#define MEDIUM_GYRO_MAGNITUDE 300//250
#define HIGH_GYRO_MAGNITUDE   450//400

//define weight value
#define	WEIGHT_VALUE_10		 10
#define	WEIGHT_VALUE_30		 30
#define	WEIGHT_VALUE_50		 50

#define	ACC_GYRO_DATA_BUF_LEN		1500
#define	VERIFY_DATA_BUF_LEN			500

//define default thresholds
#define ACC_MAGN_TRIGGER_THRES_DEF 	3.0f 	 // for acc trigger
#define FUZZY_OUT_THRES_DEF			45.0f	 // for fuzzy output
#define STD_VARIANCE_THRES_DEF		0.55f  	 // for Standard Deviation

#define MAX_GYROSCOPE_THRESHOLD 400  //max gyroscope threshold
#define MAX_ANGLE_THRESHOLD  45

//define function from raw int16_t to magnitude for acc and gyro data
#define	get_acc_magn(x) 			(((float)x)*2.0f/32768.0f)		//-+4g
#define	get_gyro_magn(x) 			(((float)x)*250.0f/28571.43f)	//-+500dps

//define minimum function
#define min(a,b) ((a)<(b)?(a):(b))


typedef enum {
  X_axis,
  Y_axis,
  Z_axis
}axis_type;

//state machine for collection data for buffer A or B.
typedef enum {
  STATE_NONE,
  STATE_STORE_BUF_A,
  STATE_STORE_BUF_B,  
  STATE_STORE_BUF_VRY,
}data_buf_sel_sm;

volatile uint16_t buf_a_ptr = 0;
volatile bool buf_a_overwrt_flag = 0;
volatile double trigger_thres_g = ACC_MAGN_TRIGGER_THRES_DEF, f_out_thres_g = FUZZY_OUT_THRES_DEF, vari_thres_g = STD_VARIANCE_THRES_DEF;
volatile data_buf_sel_sm buf_str_sm = STATE_NONE;

volatile int16_t	acc_x_data_buffer_a[ACC_GYRO_DATA_BUF_LEN] = {0}, acc_y_data_buffer_a[ACC_GYRO_DATA_BUF_LEN] = {0}, acc_z_data_buffer_a[ACC_GYRO_DATA_BUF_LEN] = {0};
volatile int16_t	gyro_x_data_buffer_a[ACC_GYRO_DATA_BUF_LEN] = {0}, gyro_y_data_buffer_a[ACC_GYRO_DATA_BUF_LEN] = {0}, gyro_z_data_buffer_a[ACC_GYRO_DATA_BUF_LEN] = {0};
volatile int16_t	acc_x_data_buffer_b[ACC_GYRO_DATA_BUF_LEN] = {0}, acc_y_data_buffer_b[ACC_GYRO_DATA_BUF_LEN] = {0}, acc_z_data_buffer_b[ACC_GYRO_DATA_BUF_LEN] = {0};
volatile int16_t	gyro_x_data_buffer_b[ACC_GYRO_DATA_BUF_LEN] = {0}, gyro_y_data_buffer_b[ACC_GYRO_DATA_BUF_LEN] = {0}, gyro_z_data_buffer_b[ACC_GYRO_DATA_BUF_LEN] = {0};
volatile float verify_acc_magn[VERIFY_DATA_BUF_LEN] = {0};

// frank_shao for test
#if defined(FALL_DETECT_TEST_MODE)
volatile float  real_acc_magn_square=0, real_std_devi=0, real_fuzzy_output=0,real_angle =0,real_max_gyro_magn = 0;
extern void ls6d_fall_detect_upl_data_req(void);
extern void ls6d_fall_detect_mmi_req(void);
static volatile uint32_t fall_data_index = 0;
#endif

volatile uint8_t suspicion_rules[9][3] =
{
  LOW_MS     , LOW_MS     , LOW_MS    ,
  LOW_MS     , MEDIUM_MS  , LOW_MS    ,
  LOW_MS     , HIGH_MS    , LOW_MS    ,
  MEDIUM_MS  , LOW_MS     , LOW_MS    ,
  MEDIUM_MS  , MEDIUM_MS  , MEDIUM_MS ,
  MEDIUM_MS  , HIGH_MS    , HIGH_MS ,
  HIGH_MS    , LOW_MS     , LOW_MS    ,
  HIGH_MS    , MEDIUM_MS  , MEDIUM_MS ,
  HIGH_MS    , HIGH_MS    , HIGH_MS
};

/**@brief Function for storing data into buffer A before suspicous event.
 */
static void store_data_buffer_a(int16_t *acc_data, int16_t *gyro_data)
{
	volatile int16_t *ptr_acc_data, *ptr_gyro_data;

	ptr_acc_data = acc_data;
	ptr_gyro_data = gyro_data;

	acc_x_data_buffer_a[buf_a_ptr]=*(ptr_acc_data+X_axis);		//int16_t x axis of acc
	acc_y_data_buffer_a[buf_a_ptr]=*(ptr_acc_data+Y_axis);		//int16_t y axis of acc
	acc_z_data_buffer_a[buf_a_ptr]=*(ptr_acc_data+Z_axis);		//int16_t z axis of acc
	gyro_x_data_buffer_a[buf_a_ptr]=*(ptr_gyro_data+X_axis);		//int16_t x axis of gyro
	gyro_y_data_buffer_a[buf_a_ptr]=*(ptr_gyro_data+Y_axis);		//int16_t y axis of gyro
	gyro_z_data_buffer_a[buf_a_ptr]=*(ptr_gyro_data+Z_axis);		//int16_t z axis of gyro

	buf_a_ptr++;								//buffer pointer add one

	if(buf_a_ptr >= ACC_GYRO_DATA_BUF_LEN) 		//need to overwritten buffer A
	{
		buf_a_ptr = 0;							//set buffer pointer to zero
		buf_a_overwrt_flag = 1;					//overwritten flag set to one
	}
}

/**@brief Function for storing one frame data into buffer B after suspicous event.
 */
static void store_one_frame_data_buffer_b(int16_t *acc_data, int16_t *gyro_data, uint16_t data_index)
{
	volatile int16_t *ptr_acc_data, *ptr_gyro_data;

	ptr_acc_data = acc_data;			//acc data pointer
	ptr_gyro_data = gyro_data;			//gyro data pointer

	acc_x_data_buffer_b[data_index]=*(ptr_acc_data+X_axis);
	acc_y_data_buffer_b[data_index]=*(ptr_acc_data+Y_axis);
	acc_z_data_buffer_b[data_index]=*(ptr_acc_data+Z_axis);
	gyro_x_data_buffer_b[data_index]=*(ptr_gyro_data+X_axis);
	gyro_y_data_buffer_b[data_index]=*(ptr_gyro_data+Y_axis);
	gyro_z_data_buffer_b[data_index]=*(ptr_gyro_data+Z_axis);
}

/**@brief Function for getting maximum gyroscope magnitude accroding to buffer B after suspicious event.
 *
 * @return maximum gyroscope magnitude in float.
 */
static float gyroscope_analyse(void)
{
	volatile uint16_t i;
	volatile float gyro_magn_square = 0, max_gyro_magn_square = 0;
	/*
	* Compute Gyroscope's Magnitude for all data after fall
	*/
	for(i=0;i<ACC_GYRO_DATA_BUF_LEN;i++)
	{
		//gyroscope magnitude square to avoid sqrt() call to save time.
		gyro_magn_square = pow(get_gyro_magn(gyro_x_data_buffer_b[i]),2)+pow(get_gyro_magn(gyro_y_data_buffer_b[i]),2)+pow(get_gyro_magn(gyro_z_data_buffer_b[i]),2);
/*		gyro_magn_square = sqrt(get_gyro_magn(gyro_x_data_buffer_b[i]) * get_gyro_magn(gyro_x_data_buffer_b[i])\
		+get_gyro_magn(gyro_y_data_buffer_b[i]) * get_gyro_magn(gyro_y_data_buffer_b[i])\
		+get_gyro_magn(gyro_z_data_buffer_b[i]) * get_gyro_magn(gyro_z_data_buffer_b[i]));*/
		if(gyro_magn_square > max_gyro_magn_square) max_gyro_magn_square = gyro_magn_square;	//get the maximum gyroscope magnitude square

	}
	return (sqrt(max_gyro_magn_square));		//do once sqrt() to get gyroscope magnitude
//	return max_gyro_magn_square;
}

/**@brief Function for getting angle accroding to buffer A and buffer B after suspicious event.
 *
 * @return angle(degree) in float.
 */
static float angle_analyse(void)
{
	volatile float angle_degree=0,avg_index=50;
	volatile float start_avg_accel_x=0,start_avg_accel_y=0,start_avg_accel_z=0;
	volatile float end_avg_accel_x=0, end_avg_accel_y=0, end_avg_accel_z=0;
	volatile float num=0,denom=0;
	volatile double angle=0;
	volatile uint16_t i;



	//get start index acc data in buffer A start
		if(buf_a_overwrt_flag)		//overwirtten
		{
			if(buf_a_ptr >= 150)
			{
				for(i=buf_a_ptr - 150;i<buf_a_ptr - 150 + 50;i++)
				{
					start_avg_accel_x +=acc_x_data_buffer_a[i];
					start_avg_accel_y +=acc_y_data_buffer_a[i];
					start_avg_accel_z +=acc_z_data_buffer_a[i];
				}
			}
			else if((buf_a_ptr>100) && (buf_a_ptr<150))
			{
				for(i=0;i<buf_a_ptr - 100 ;i++)
				{
					start_avg_accel_x +=acc_x_data_buffer_a[i];
					start_avg_accel_y +=acc_y_data_buffer_a[i];
					start_avg_accel_z +=acc_z_data_buffer_a[i];
				}
				for(i=ACC_GYRO_DATA_BUF_LEN - (150 -buf_a_ptr);i< ACC_GYRO_DATA_BUF_LEN;i++)
				{
					start_avg_accel_x +=acc_x_data_buffer_a[i];
					start_avg_accel_y +=acc_y_data_buffer_a[i];
					start_avg_accel_z +=acc_z_data_buffer_a[i];
				}
			}
			else  //  (buf_a_ptr<=150)
			{
				for(i=ACC_GYRO_DATA_BUF_LEN - (150 -buf_a_ptr);i< ACC_GYRO_DATA_BUF_LEN - (150 -buf_a_ptr) + 50;i++)
				{
					start_avg_accel_x +=acc_x_data_buffer_a[i];
					start_avg_accel_y +=acc_y_data_buffer_a[i];
					start_avg_accel_z +=acc_z_data_buffer_a[i];
				}
			}
		}
		else			//not overwirtten
		{
			if(buf_a_ptr > 50)		//last 50 frames data
			{
				for(i=buf_a_ptr - 50;i<buf_a_ptr;i++)
				{
					start_avg_accel_x +=acc_x_data_buffer_a[i];
					start_avg_accel_y +=acc_y_data_buffer_a[i];
					start_avg_accel_z +=acc_z_data_buffer_a[i];
				}
			}
			else
			{
				for(i=0;i<buf_a_ptr;i++)
				{
					start_avg_accel_x +=acc_x_data_buffer_a[i];
					start_avg_accel_y +=acc_y_data_buffer_a[i];
					start_avg_accel_z +=acc_z_data_buffer_a[i];
				}
				avg_index = buf_a_ptr;
			}
		}



//get start index acc data in buffer A end

	start_avg_accel_x /=avg_index;										//get average for each axis
	start_avg_accel_y /=avg_index;
	start_avg_accel_z /=avg_index;

	start_avg_accel_x =  get_acc_magn(start_avg_accel_x);			//get acc magnitude
	start_avg_accel_y = get_acc_magn(start_avg_accel_y);
	start_avg_accel_z = get_acc_magn(start_avg_accel_z);

	for(i=1050;i>1000;i--)
	{
		end_avg_accel_x +=acc_x_data_buffer_b[i];
		end_avg_accel_y +=acc_y_data_buffer_b[i];
		end_avg_accel_z +=acc_z_data_buffer_b[i];
	}
	end_avg_accel_x /=50.0f;										//get average for each axis
	end_avg_accel_y /=50.0f;
	end_avg_accel_z /=50.0f;

	end_avg_accel_x = get_acc_magn(end_avg_accel_x);				//get acc magnitude
	end_avg_accel_y = get_acc_magn(end_avg_accel_y);
	end_avg_accel_z = get_acc_magn(end_avg_accel_z);

	num= (start_avg_accel_x*end_avg_accel_x) + (start_avg_accel_y*end_avg_accel_y) + (start_avg_accel_z*end_avg_accel_z);
	denom= (pow(start_avg_accel_x,2) + pow(start_avg_accel_y,2) + pow(start_avg_accel_z,2)) * (pow(end_avg_accel_x,2)+pow(end_avg_accel_y,2)+pow(end_avg_accel_z,2));
	angle=acos(num/sqrt(denom));

	angle_degree=angle *(180.0f/3.14159265f);						//get angle in degree

	return angle_degree;
}

/**@brief Function for getting input degree according to angle or gyroscope magnitude.
 *
 * @return input degree in float.
 */
static float get_input_degree(float x, float a, float b, float c, float d)
{
	volatile float re_val=0;

	if (d == b)					 // Rshoulder
	{
		if (x >= b) 			 		re_val = 1;
		else if (x > a && x < b) 		re_val = (x - a) / (b - a);
		else if (x <= a)		 		re_val = 0;
	}
	else if (d == c)			 // Triangle
	{
		if (x <= a)				 		re_val = 0;
		else if (x == b)     	 		re_val = 1;
		else if (x < b)			 		re_val = (x - a) / (b - a);
		else if (x >= c)		 		re_val = 0;
		else if (x > b)			 		re_val = (c - x) / (c - b);
	}
	else if (d == a)			 //Lshoulder
	{
		if (x <= c)				 		re_val = 1;
		else if (x > c && x < d) 		re_val = (d - x) / (d - c);
		else if (x >= d)		 		re_val = 0;
	}
	else re_val = 0;
	return re_val;
}

/**@brief Function for getting weight according to memship.
 *
 * @return weight in uint8_t.
 */
static uint8_t get_output_from_memship(uint8_t memship)
{
	if 		(memship == LOW_MS)    return WEIGHT_VALUE_10;
	else if (memship == MEDIUM_MS) return WEIGHT_VALUE_30;
	else if (memship == HIGH_MS)   return WEIGHT_VALUE_50;
	else return 0;
}

/**@brief Function for getting fuzzy output.
 *
 * @return fuzzy analysis output in float.
 */
static float fuzzy_analyse(float angle, float max_gyro_magn)
{
	volatile uint8_t i=0;
	volatile float fire_strength[9];
	volatile float sum_firestrenths = 0;
	volatile float output_value=0;

	volatile float low_angle_degree=0, medium_angle_degree=0, high_angle_degree=0;
	volatile float low_gyro_magnitude_degree=0, medium_gyro_magnitude_degree=0, high_gyro_magnitude_degree=0;
	volatile float current_angle = angle;  // should compute this value continously from sensor
	volatile float current_max_gyro_magn = max_gyro_magn;

	//===================================================1-Fuzzification
	low_angle_degree =    get_input_degree(current_angle, MEDIUM_ANGLE, 0, LOW_ANGLE, MEDIUM_ANGLE);
	medium_angle_degree = get_input_degree(current_angle, LOW_ANGLE, MEDIUM_ANGLE, HIGH_ANGLE, HIGH_ANGLE);
	high_angle_degree =   get_input_degree(current_angle, MEDIUM_ANGLE, HIGH_ANGLE, 0, HIGH_ANGLE);

	low_gyro_magnitude_degree =    get_input_degree(current_max_gyro_magn, MEDIUM_GYRO_MAGNITUDE, 0, LOW_GYRO_MAGNITUDE, MEDIUM_GYRO_MAGNITUDE);
	medium_gyro_magnitude_degree = get_input_degree(current_max_gyro_magn, LOW_GYRO_MAGNITUDE, MEDIUM_GYRO_MAGNITUDE, HIGH_GYRO_MAGNITUDE, HIGH_GYRO_MAGNITUDE);
	high_gyro_magnitude_degree =   get_input_degree(current_max_gyro_magn, MEDIUM_GYRO_MAGNITUDE, HIGH_GYRO_MAGNITUDE, 0, HIGH_GYRO_MAGNITUDE);

	//===================================================2-Fire Strength
	fire_strength[0] = min(low_angle_degree   , low_gyro_magnitude_degree);
	fire_strength[1] = min(low_angle_degree   , medium_gyro_magnitude_degree);
	fire_strength[2] = min(low_angle_degree   , high_gyro_magnitude_degree);
	fire_strength[3] = min(medium_angle_degree, low_gyro_magnitude_degree);
	fire_strength[4] = min(medium_angle_degree, medium_gyro_magnitude_degree);
	fire_strength[5] = min(medium_angle_degree, high_gyro_magnitude_degree);
	fire_strength[6] = min(high_angle_degree  , low_gyro_magnitude_degree);
	fire_strength[7] = min(high_angle_degree  , medium_gyro_magnitude_degree);
	fire_strength[8] = min(high_angle_degree  , high_gyro_magnitude_degree);

	//======================================================3- linguistic and numric output
	for (i = 0; i < 9; i++)
	{
		output_value += fire_strength[i] * get_output_from_memship(suspicion_rules[i][2]);
		sum_firestrenths += fire_strength[i];
	}

	output_value /= sum_firestrenths;
	return output_value;
}

/**@brief Function for clear buffer B when verification needed and do it before verification.
 */
static void clear_acc_data_buf_when_verify(void)
{
	volatile uint16_t i;
	for(i=0;i<ACC_GYRO_DATA_BUF_LEN;i++)
	{
		acc_x_data_buffer_b[i] = 0;		//set zero
		acc_y_data_buffer_b[i] = 0;
		acc_z_data_buffer_b[i] = 0;
	}
}

/**@brief Function for storing one frame acc data for verification.
 */
static void get_one_frame_acc_data_to_verify(int16_t *acc_data, uint16_t data_index)
{
	volatile int16_t *ptr_acc_data;

	ptr_acc_data = acc_data;

	acc_x_data_buffer_b[data_index]=*(ptr_acc_data+X_axis);
	acc_y_data_buffer_b[data_index]=*(ptr_acc_data+Y_axis);
	acc_z_data_buffer_b[data_index]=*(ptr_acc_data+Z_axis);
}

/**@brief Function for getting fall verification result.
 *
 * @return std_deviation in float.
 */
static float fall_verification(void)
{
	volatile uint16_t i;
	volatile float std_deviation = 0, variance=0,average = 0;

	memset(verify_acc_magn,0x00,VERIFY_DATA_BUF_LEN);
	//compute acc magnitude
	for(i=0;i<VERIFY_DATA_BUF_LEN;i++)
	{
		verify_acc_magn[i] = sqrt(pow(get_acc_magn(acc_x_data_buffer_b[i]),2)+ pow(get_acc_magn(acc_y_data_buffer_b[i]),2) + pow(get_acc_magn(acc_z_data_buffer_b[i]),2));
		average += (verify_acc_magn[i] - average)/(i+1);
	}

	//compute variance and standard deviation to a base 0.5g
	for(i=0;i<VERIFY_DATA_BUF_LEN;i++)
	{
		variance += pow((verify_acc_magn[i]-average),2);
	}
	std_deviation = sqrt(variance/(float)VERIFY_DATA_BUF_LEN);

	return std_deviation;
}

/**@brief Function for algorithm init.
 * @input trigger_thres: trigger threshold, f_out_thres: fuzzy output threshold, vari_thres: standard deviation threshold.
 * @return 1: init success.
 */
bool algorithm_init(double sensitivity)
{
	volatile uint16_t i;
	for(i=0;i<ACC_GYRO_DATA_BUF_LEN;i++)
	{
		acc_x_data_buffer_a[i] = 0;		//clear buffer A
		acc_y_data_buffer_a[i] = 0;
		acc_z_data_buffer_a[i] = 0;
		gyro_x_data_buffer_a[i] = 0;
		gyro_y_data_buffer_a[i] = 0;
		gyro_z_data_buffer_a[i] = 0;

		acc_x_data_buffer_b[i] = 0;		//clear buffer B
		acc_y_data_buffer_b[i] = 0;
		acc_z_data_buffer_b[i] = 0;
		gyro_x_data_buffer_b[i] = 0;
		gyro_y_data_buffer_b[i] = 0;
		gyro_z_data_buffer_b[i] = 0;
	}
	buf_a_ptr = 0;
	buf_a_overwrt_flag = 0;
	buf_str_sm = STATE_NONE;

	vari_thres_g = sensitivity;
	return 1;
}

#if defined(PRINT_RAW_DATA_TEST_MODE)
volatile int32_t raw_data_index = 0;
double test_acc_data_x,test_acc_data_y,test_acc_data_z,test_gyro_data_x,test_gyro_data_y,test_gyro_data_z,test_gyro_magn,max_test_gyro_magn;
void get_test_raw_data(double* acc_x,double* acc_y,double* acc_z,double* gyro_x,double* gyro_y,double* gyro_z,double* gyro_magn,double* max_gyro_magn)
{
	*acc_x = test_acc_data_x;
	*acc_y = test_acc_data_y;
	*acc_z = test_acc_data_z;
	*gyro_x = test_gyro_data_x;
	*gyro_y = test_gyro_data_y;
	*gyro_z = test_gyro_data_z;
	*gyro_magn = test_gyro_magn;
	*max_gyro_magn = max_test_gyro_magn;
}
#endif


/**@brief Function for algorithm analysis.
 * @input acc_data: acc data(one frame) pointer, gyro_data: gyro data(one frame) pointer.
 * @return algorithm analysis result, refer to algo_result_ret_value.
 */
uint8_t algorithm_analyse(int16_t *acc_data, int16_t *gyro_data)
{
	volatile int16_t *ptr_acc_data, *ptr_gry_data;
	volatile float  std_devi=0;
	static volatile float  acc_magn_square=0, cur_angle=0, cur_max_gyro_magn=0, fuzzy_output=0;
	static volatile uint16_t data_frame_index = 0, very_data_frame_index = 0;

//	fall_detetc_result  result = NOT_FALL_DOWN;
	volatile uint8_t result = 0;
//	algo_result_ret_value result_val;
//	memset(&result_val, 0, sizeof(result_val));

	ptr_acc_data = acc_data, ptr_gry_data = gyro_data;

#if defined(PRINT_RAW_DATA_TEST_MODE)
{
	uint8_t test_buff[128] = {0};
	test_acc_data_x = get_acc_magn(ptr_acc_data[0]);
		test_acc_data_y = get_acc_magn(ptr_acc_data[1]);
		test_acc_data_z = get_acc_magn(ptr_acc_data[2]);

		test_gyro_data_x = get_gyro_magn(ptr_gry_data[0]);
		test_gyro_data_y = get_gyro_magn(ptr_gry_data[1]);
		test_gyro_data_z = get_gyro_magn(ptr_gry_data[2]);

		test_gyro_magn = sqrt(pow(test_gyro_data_x,2)+pow(test_gyro_data_y,2)+pow(test_gyro_data_z,2));
		if(test_gyro_magn>max_test_gyro_magn)
			max_test_gyro_magn = test_gyro_magn;
	kal_prompt_trace(MOD_UEM,"AX:%d,Ay:%d,Az:%d,gx:%d,gy:%d,gz:%d",
		ptr_acc_data[0],ptr_acc_data[1],ptr_acc_data[2],ptr_gry_data[0],ptr_gry_data[1],ptr_gry_data[2]);
	sprintf(test_buff,"gyro_magn:%.2f",test_gyro_magn);
	kal_prompt_trace(MOD_UEM,"%s",test_buff);
	


	raw_data_index++;
   
	if(raw_data_index%1500 == 0)
	{
		raw_data_index = 0;
		
		ls6d_fall_detect_mmi_req();
	}
}
	// frank_shao for test  start
#else
	if(buf_str_sm == STATE_NONE) 									//algorithm is inited already
	{
		buf_a_ptr=0;buf_a_overwrt_flag=0;
		acc_magn_square=0, cur_angle=0, cur_max_gyro_magn=0, fuzzy_output=0;data_frame_index=0;very_data_frame_index=0;
		buf_str_sm = STATE_STORE_BUF_A;
	}

	else if(buf_str_sm == STATE_STORE_BUF_A) 							//store data into buffer A continously state
	{
		store_data_buffer_a(ptr_acc_data, ptr_gry_data);
		acc_magn_square = pow(get_acc_magn(ptr_acc_data[X_axis]),2)+ pow(get_acc_magn(ptr_acc_data[Y_axis]),2) + pow(get_acc_magn(ptr_acc_data[Z_axis]),2);
		if( acc_magn_square > pow(trigger_thres_g,2)) 					//if acc magnitude exceed trigger_thers_g, now is 3g
		{
			buf_str_sm = STATE_STORE_BUF_B;							//turn to buffer B storing
			data_frame_index = 0;
			cur_max_gyro_magn=0;
			cur_angle=0;
			fuzzy_output=0;
		}
	}
	else if(buf_str_sm == STATE_STORE_BUF_B)							//store data into buffer B continously state
	{
		store_one_frame_data_buffer_b(ptr_acc_data, ptr_gry_data, data_frame_index);
		data_frame_index++;
		if(data_frame_index >= ACC_GYRO_DATA_BUF_LEN)					//already store 1500 frames data
		{
			#if defined(FALL_DETECT_TEST_MODE)
			volatile char test_buffer[128] = {0};  // frank_shao for test  start
			#endif

			data_frame_index = 0;
			cur_max_gyro_magn=gyroscope_analyse();						//calculate maximum gyroscope magnitude
			cur_angle=angle_analyse();									//calculate angle
			fuzzy_output = fuzzy_analyse(cur_angle, cur_max_gyro_magn);	//fuzzy analyse
			// frank_shao for test  start
			#if defined(FALL_DETECT_TEST_MODE)
			//sprintf(test_buffer,"cur_max_gyro_magn:%f,cur_angle:%f,fuzzy_output:%f\r\n",cur_max_gyro_magn,cur_angle,fuzzy_output);
			//dbg_print("%s",test_buffer);
			real_acc_magn_square = acc_magn_square;
			real_fuzzy_output = fuzzy_output;
			real_std_devi =  std_devi;
			real_angle = cur_angle;
			real_max_gyro_magn = cur_max_gyro_magn;
			fall_data_index++;
			ls6d_fall_detect_mmi_req();
			#endif
			// frank_shao add
			if((cur_max_gyro_magn > MAX_GYROSCOPE_THRESHOLD) && (cur_angle > MAX_ANGLE_THRESHOLD))   // max gyroscope threshold  and max angle
			{
				// frank_shao for test  end
				if(fuzzy_output > f_out_thres_g)							//if fuzzy output exceed f_out_thres_g, now is 45
				{
					buf_str_sm = STATE_STORE_BUF_VRY;						//turn to fall verification
					clear_acc_data_buf_when_verify();						//clear acc data in buffer B for store new data
					very_data_frame_index = 0;
				}
				else
				{
					//result = SUSPICOUS_ENENT;								//fuzzy output not exceed f_out_thres_g, so detect result is just suspicious event
					buf_str_sm = STATE_NONE;								//turn to storing buffer A state
				}
			}
			else
			{
				buf_str_sm = STATE_NONE;								//turn to storing buffer A state
			}
		}
	}
	else if(buf_str_sm == STATE_STORE_BUF_VRY)							//fall verification state
	{
		get_one_frame_acc_data_to_verify(ptr_acc_data, very_data_frame_index);
		very_data_frame_index++;
		if( very_data_frame_index >= VERIFY_DATA_BUF_LEN)				//already store 1000 frames acc data
		{
			#if defined(FALL_DETECT_TEST_MODE)
			volatile char test_buffer[128] = {0};  // frank_shao for test  start
			#endif
			std_devi = fall_verification();
			#if defined(FALL_DETECT_TEST_MODE)
			real_std_devi =  std_devi;
			//sprintf(test_buffer,"std_devi:%f\r\n",std_devi);
			//dbg_print("%s",test_buffer);
			ls6d_fall_detect_mmi_req();
			#endif
			if(std_devi < vari_thres_g)			{
				result=1;//result = FALL_DOWN;				//if standard deviation less than vari_thres_g, now is 0.5g, detect result is fall down, if not, detect result is fall down not reach standard deviation
			}
			//else 						result = FALL_DOWN_NOT_REACH_STD;
			buf_str_sm = STATE_NONE;									//turn to storing buffer A state

		}
	}
	#endif
	return result;
}

void set_tri_fo_std_thres(double tri_thr, double fo_thr, double std_thr)
{
	trigger_thres_g = tri_thr;		//set thresholds
	f_out_thres_g   = fo_thr;
	vari_thres_g    = std_thr;
}

void get_tri_fo_std_thres(double *tri_thr, double *fo_thr, double *std_thr)
{
	*tri_thr = trigger_thres_g;
	*fo_thr = f_out_thres_g;
	*std_thr = vari_thres_g;
}

#if defined(FALL_DETECT_TEST_MODE)
void get_real_tri_fo_std_thres(double *tri_thr, double *fo_thr, double *std_thr, double *angle, double *svmg,uint32_t *index)
{
	*tri_thr = real_acc_magn_square;
	*fo_thr = real_fuzzy_output;
	*std_thr = real_std_devi;
	*angle = real_angle;
	*svmg = real_max_gyro_magn;
	*index = fall_data_index;
}

#endif
