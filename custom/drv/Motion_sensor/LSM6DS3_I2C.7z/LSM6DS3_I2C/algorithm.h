/*****************************************************************************
* File Name          : fall_detect_algorithm.h
* Author             : Young
* Version            : v1.0
* Date               : 12/05/2019 
* Description        : head file for fall detection algorithm 
*                      
* HISTORY:
* Date               |	Modification                    |	Author
* 12/05/2019         |	Initial Revision                |	Young

********************************************************************************/
#ifndef ALGORITHM_H__
#define ALGORITHM_H__

#include <stdint.h>
#include <stdbool.h>
#include "kal_general_types.h"

//typedef kal_bool     bool;

//void algorithm_init(double sensitivity);
uint8_t algorithm_analyse(int16_t *acc_data_an, int16_t *gyro_data_an);
uint8_t algo_analyse(float acceleration_mg [ 3 ], float angular_rate_mdps [ 3 ]);
//uint8_t algo_analyse(float acceleration_g [3], float angular_rate_dps [3]);
typedef struct {
	volatile float svma;
	volatile float svmg;
	volatile float cal_angle;
	volatile float f_out;
	volatile float std_devi;
	volatile double trigger_thres, f_out_thres, vari_thres;
	volatile uint8_t result;
}algo_result_ret_value;

//kal_bool algorithm_init(kal_bool set_flag, double tri_thr, double fo_thr, double vari_thr);

//algo_result_ret_value algorithm_analyse(int16_t* acc_data, int16_t* gyro_data);
extern algo_result_ret_value lsm6ds3_data;
extern algo_result_ret_value lsm6ds3_data_temp;


#endif

